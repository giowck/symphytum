hiddenimports = ["django.db.backends.oracle.compiler"]

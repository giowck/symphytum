from hooks.hookutils import mpl_data_dir

dir = mpl_data_dir()
datas = [
    (dir, ""),
]

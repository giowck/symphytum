# Contributed by pyplant@googlemail.com
hiddenimports = ['_elementpath', 'gzip']

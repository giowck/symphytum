if __file__ != "test_filename.py":
   raise ValueError(__file__)


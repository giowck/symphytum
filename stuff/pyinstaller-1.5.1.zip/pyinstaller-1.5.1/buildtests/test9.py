#!/usr/bin/env python
import time
print time.strptime(time.ctime())

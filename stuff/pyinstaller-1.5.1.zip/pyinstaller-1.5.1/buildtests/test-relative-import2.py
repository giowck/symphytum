import relimp2.bar
import relimp2.bar.bar2

relimp2.bar.say_hello_please()
relimp2.bar.bar2.say_hello_please()

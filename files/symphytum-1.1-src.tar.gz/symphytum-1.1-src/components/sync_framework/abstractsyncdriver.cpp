/*
 *  Copyright (c) 2012 Giorgio Wicklein <giorgio.wicklein@giowisys.com>
 */

//-----------------------------------------------------------------------------
// Hearders
//-----------------------------------------------------------------------------

#include "abstractsyncdriver.h"


//-----------------------------------------------------------------------------
// Public
//-----------------------------------------------------------------------------

AbstractSyncDriver::AbstractSyncDriver(QObject *parent) :
    QObject(parent)
{
}

AbstractSyncDriver::~AbstractSyncDriver()
{

}
